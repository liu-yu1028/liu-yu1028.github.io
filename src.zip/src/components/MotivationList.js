import React, { Component } from "react";
import "./css/PosList.css";

export default class MotivationList extends Component {
	render() {
		return (
			<div
				style={{
					width: "100%",
					alignItems: "center",
					justifyContent: "center",
					textAlign: "center",
				}}
			>
				<div className="iframe-container">
					<iframe src="https://www.linkedin.com/embed/feed/update/urn:li:share:6685395885414727680" frameborder="0" allowfullscreen="" title="Embedded post"></iframe>
				</div>
				<div className="iframe-container">
					<iframe
						src="https://www.linkedin.com/embed/feed/update/urn:li:share:6679392875739971584"
						frameborder="0"
						allowfullscreen=""
						title="Embedded post"
					></iframe>
				</div>
				<div className="iframe-container">
					<iframe
						src="https://www.linkedin.com/embed/feed/update/urn:li:share:6670180112002088960"
						frameborder="0"
						allowfullscreen=""
						title="Embedded post"
					></iframe>
				</div>
				<div className="iframe-container">
					<iframe
						src="https://www.linkedin.com/embed/feed/update/urn:li:share:6666568457087258624"
						frameborder="0"
						allowfullscreen=""
						title="Embedded post"
					></iframe>
				</div>
				<div className="iframe-container">
					<iframe
						src="https://www.linkedin.com/embed/feed/update/urn:li:share:6666330192681799681"
						frameborder="0"
						allowfullscreen=""
						title="Embedded post"
					></iframe>
				</div>
				<div className="iframe-container">
					<iframe
						src="https://www.linkedin.com/embed/feed/update/urn:li:share:6667746806702706688"
						frameborder="0"
						allowfullscreen=""
						title="Embedded post"
					></iframe>
				</div>
				<div className="iframe-container">
					<iframe
						src="https://www.linkedin.com/embed/feed/update/urn:li:share:6664882630175129600"
						frameborder="0"
						allowfullscreen=""
						title="Embedded post"
					></iframe>
				</div>
				<div className="iframe-container">
					<iframe
						src="https://www.linkedin.com/embed/feed/update/urn:li:share:6660136729598668801"
						frameborder="0"
						allowfullscreen=""
						title="Embedded post"
					></iframe>
				</div>
				<div className="iframe-container">
					<iframe
						src="https://www.linkedin.com/embed/feed/update/urn:li:share:6658244234556039168"
						frameborder="0"
						allowfullscreen=""
						title="Embedded post"
					></iframe>
				</div>
				<div className="iframe-container">
					<iframe
						src="https://www.linkedin.com/embed/feed/update/urn:li:share:6656046076367302657"
						frameborder="0"
						allowfullscreen=""
						title="Embedded post"
					></iframe>
				</div>
				<div className="iframe-container">
					<iframe
						src="https://www.linkedin.com/embed/feed/update/urn:li:share:6631756845553942528"
						frameborder="0"
						allowfullscreen=""
						title="Embedded post"
					></iframe>
				</div>
			</div>
		);
	}
}
