import React, { Component } from 'react';
import './css/PosList.css';

export default class TechList extends Component {
    render(){
        return (
					<div
						style={{
							width: "100%",
							alignItems: "center",
							justifyContent: "center",
							textAlign: "center",
						}}
					>
						<div className="iframe-container">
							<iframe src="https://www.linkedin.com/embed/feed/update/urn:li:share:6689371788763246592" frameborder="0" allowfullscreen="" title="Embedded post"></iframe>
						</div>
						<div className="iframe-container">
							<iframe src="https://www.linkedin.com/embed/feed/update/urn:li:share:6688998600409665536" frameborder="0" allowfullscreen="" title="Embedded post"></iframe>
						</div>
						<div className="iframe-container">
							<iframe src="https://www.linkedin.com/embed/feed/update/urn:li:share:6687195102084902912" frameborder="0" allowfullscreen="" title="Embedded post"></iframe>
						</div>
						<div className="iframe-container">
							<iframe src="https://www.linkedin.com/embed/feed/update/urn:li:share:6686833036065026048" frameborder="0" allowfullscreen="" title="Embedded post"></iframe>
						</div>
						<div className="iframe-container">
							<iframe src="https://www.linkedin.com/embed/feed/update/urn:li:share:6686466651497500672" frameborder="0" allowfullscreen="" title="Embedded post"></iframe>
						</div>
						<div className="iframe-container">
							<iframe src="https://www.linkedin.com/embed/feed/update/urn:li:share:6686113763403304960" frameborder="0" allowfullscreen="" title="Embedded post"></iframe>
						</div>
						<div className="iframe-container">
							<iframe src="https://www.linkedin.com/embed/feed/update/urn:li:share:6684652595497193472" frameborder="0" allowfullscreen="" title="Embedded post"></iframe>
						</div>
						<div className="iframe-container">
							<iframe src="https://www.linkedin.com/embed/feed/update/urn:li:share:6683564749315284992" frameborder="0" allowfullscreen="" title="Embedded post"></iframe>
						</div>
						<div className="iframe-container">
							<iframe src="https://www.linkedin.com/embed/feed/update/urn:li:share:6683202006913445888" frameborder="0" allowfullscreen="" title="Embedded post"></iframe>
						</div>
						<div className="iframe-container">
							<iframe src="https://www.linkedin.com/embed/feed/update/urn:li:share:6682852184515735552" frameborder="0" allowfullscreen="" title="Embedded post"></iframe>
						</div>
						<div className="iframe-container">
							<iframe src="https://www.linkedin.com/embed/feed/update/urn:li:share:6682510098025201664" frameborder="0" allowfullscreen="" title="Embedded post"></iframe>
						</div>
						<div className="iframe-container">
							<iframe src="https://www.linkedin.com/embed/feed/update/urn:li:share:6682231680901636096" frameborder="0" allowfullscreen="" title="Embedded post"></iframe>
						</div>
						<div className="iframe-container">
							<iframe src="https://www.linkedin.com/embed/feed/update/urn:li:share:6681399607408246784" frameborder="0" allowfullscreen="" title="Embedded post"></iframe>
						</div>
						<div className="iframe-container">
							<iframe src="https://www.linkedin.com/embed/feed/update/urn:li:share:6681042345128927232" frameborder="0" allowfullscreen="" title="Embedded post"></iframe>
						</div>
						<div className="iframe-container">
							<iframe src="https://www.linkedin.com/embed/feed/update/urn:li:share:6680669182666780672" frameborder="0" allowfullscreen="" title="Embedded post"></iframe>
						</div>
						<div className="iframe-container">
							<iframe src="https://www.linkedin.com/embed/feed/update/urn:li:share:6680474283547885568" frameborder="0" allowfullscreen="" title="Embedded post"></iframe>
						</div>
						<div className="iframe-container">
							<iframe src="https://www.linkedin.com/embed/feed/update/urn:li:ugcPost:6680379547235426304" frameborder="0" allowfullscreen="" title="Embedded post"></iframe>
						</div>
						<div className="iframe-container">
							<iframe
								src="https://www.linkedin.com/embed/feed/update/urn:li:share:6676810475562418176"
								frameborder="0"
								allowfullscreen=""
								title="Embedded post"
							></iframe>
						</div>
						<div className="iframe-container">
							<iframe
								src="https://www.linkedin.com/embed/feed/update/urn:li:share:6676383780728643584"
								frameborder="0"
								allowfullscreen=""
								title="Embedded post"
							></iframe>
						</div>
						<div className="iframe-container">
							<iframe
								src="https://www.linkedin.com/embed/feed/update/urn:li:share:6675949740720488448"
								frameborder="0"
								allowfullscreen=""
								title="Embedded post"
							></iframe>
						</div>
						<div className="iframe-container">
							<iframe
								src="https://www.linkedin.com/embed/feed/update/urn:li:share:6675243386603151360"
								frameborder="0"
								allowfullscreen=""
								title="Embedded post"
							></iframe>
						</div>
						<div className="iframe-container">
							<iframe
								src="https://www.linkedin.com/embed/feed/update/urn:li:share:6674872075477491712"
								frameborder="0"
								allowfullscreen=""
								title="Embedded post"
							></iframe>
						</div>
						<div className="iframe-container">
							<iframe
								src="https://www.linkedin.com/embed/feed/update/urn:li:share:6674515406813839360"
								frameborder="0"
								allowfullscreen=""
								title="Embedded post"
							></iframe>
						</div>
						<div className="iframe-container">
							<iframe
								src="https://www.linkedin.com/embed/feed/update/urn:li:share:6673794118453473281"
								frameborder="0"
								allowfullscreen=""
								title="Embedded post"
							></iframe>
						</div>
						<div className="iframe-container">
							<iframe
								src="https://www.linkedin.com/embed/feed/update/urn:li:share:6673420890698600448"
								frameborder="0"
								allowfullscreen=""
								title="Embedded post"
							></iframe>
						</div>
						<div className="iframe-container">
							<iframe
								src="https://www.linkedin.com/embed/feed/update/urn:li:share:6673055924732743680"
								frameborder="0"
								allowfullscreen=""
								title="Embedded post"
							></iframe>
						</div>
						<div className="iframe-container">
							<iframe
								src="https://www.linkedin.com/embed/feed/update/urn:li:share:6671983640597061632"
								frameborder="0"
								allowfullscreen=""
								title="Embedded post"
							></iframe>
						</div>
						<div className="iframe-container">
							<iframe
								src="https://www.linkedin.com/embed/feed/update/urn:li:share:6671616161534357504"
								frameborder="0"
								allowfullscreen=""
								title="Embedded post"
							></iframe>
						</div>
						<div className="iframe-container">
							<iframe
								src="https://www.linkedin.com/embed/feed/update/urn:li:share:6669813565815427072"
								frameborder="0"
								allowfullscreen=""
								title="Embedded post"
							></iframe>
						</div>
						<div className="iframe-container">
							<iframe
								src="https://www.linkedin.com/embed/feed/update/urn:li:share:6668347174952296448"
								frameborder="0"
								allowfullscreen=""
								title="Embedded post"
							></iframe>
						</div>
						<div className="iframe-container">
							<iframe
								src="https://www.linkedin.com/embed/feed/update/urn:li:share:6667988723910746112"
								frameborder="0"
								allowfullscreen=""
								title="Embedded post"
							></iframe>
						</div>
						<div className="iframe-container">
							<iframe
								src="https://www.linkedin.com/embed/feed/update/urn:li:share:6667637122863906817"
								frameborder="0"
								allowfullscreen=""
								title="Embedded post"
							></iframe>
						</div>
						<div className="iframe-container">
							<iframe
								src="https://www.linkedin.com/embed/feed/update/urn:li:share:6667266377868550144"
								frameborder="0"
								allowfullscreen=""
								title="Embedded post"
							></iframe>
						</div>
						<div className="iframe-container">
							<iframe
								src="https://www.linkedin.com/embed/feed/update/urn:li:share:6666914323417432064"
								frameborder="0"
								allowfullscreen=""
								title="Embedded post"
							></iframe>
						</div>
						<div className="iframe-container">
							<iframe
								src="https://www.linkedin.com/embed/feed/update/urn:li:share:6666189625217867776"
								frameborder="0"
								allowfullscreen=""
								title="Embedded post"
							></iframe>
						</div>
						<div className="iframe-container">
							<iframe
								src="https://www.linkedin.com/embed/feed/update/urn:li:share:6665816661981036544"
								frameborder="0"
								allowfullscreen=""
								title="Embedded post"
							></iframe>
						</div>
						<div className="iframe-container">
							<iframe
								src="https://www.linkedin.com/embed/feed/update/urn:li:share:6664385675858718720"
								frameborder="0"
								allowfullscreen=""
								title="Embedded post"
							></iframe>
						</div>
						<div className="iframe-container">
							<iframe
								src="https://www.linkedin.com/embed/feed/update/urn:li:share:6664079713327292417"
								frameborder="0"
								allowfullscreen=""
								title="Embedded post"
							></iframe>
						</div>
						<div className="iframe-container">
							<iframe
								src="https://www.linkedin.com/embed/feed/update/urn:li:share:6662225600054472704"
								frameborder="0"
								allowfullscreen=""
								title="Embedded post"
							></iframe>
						</div>
						<div className="iframe-container">
							<iframe
								src="https://www.linkedin.com/embed/feed/update/urn:li:share:6661526094799343617"
								frameborder="0"
								allowfullscreen=""
								title="Embedded post"
							></iframe>
						</div>
						<div className="iframe-container">
							<iframe
								src="https://www.linkedin.com/embed/feed/update/urn:li:share:6661130203785502720"
								frameborder="0"
								allowfullscreen=""
								title="Embedded post"
							></iframe>
						</div>
						<div className="iframe-container">
							<iframe
								src="https://www.linkedin.com/embed/feed/update/urn:li:share:6660079460727037952"
								frameborder="0"
								allowfullscreen=""
								title="Embedded post"
							></iframe>
						</div>
						<div className="iframe-container">
							<iframe
								src="https://www.linkedin.com/embed/feed/update/urn:li:share:6659720997375213568"
								height="1037"
								width="504"
								frameborder="0"
								allowfullscreen=""
								title="Embedded post"
							></iframe>
						</div>
						<div className="iframe-container">
							<iframe
								src="https://www.linkedin.com/embed/feed/update/urn:li:share:6658645628698050560"
								frameborder="0"
								allowfullscreen=""
								title="Embedded post"
							></iframe>
						</div>
						<div className="iframe-container">
							<iframe
								src="https://www.linkedin.com/embed/feed/update/urn:li:share:6657887147380576256"
								frameborder="0"
								allowfullscreen=""
								title="Embedded post"
							></iframe>
						</div>
						<div className="iframe-container">
							<iframe
								src="https://www.linkedin.com/embed/feed/update/urn:li:share:6656426516462825472"
								frameborder="0"
								allowfullscreen=""
								title="Embedded post"
							></iframe>
						</div>
						<div className="iframe-container">
							<iframe
								src="https://www.linkedin.com/embed/feed/update/urn:li:share:6636176390377041920"
								frameborder="0"
								allowfullscreen=""
								title="Embedded post"
							></iframe>
						</div>
					</div>
				);
    }
}