import React, { Component } from "react";
import "./css/PosList.css";

export default class SelfBrandingList extends Component {
	render() {
		return (
			<div
				style={{
					width: "100%",
					alignItems: "center",
					justifyContent: "center",
					textAlign: "center",
				}}
			>
				<div className="iframe-container">
					<iframe src="https://www.linkedin.com/embed/feed/update/urn:li:share:6684653939964551168" frameborder="0" allowfullscreen="" title="Embedded post"></iframe>
				</div>
				<div className="iframe-container">
					<iframe
						src="https://www.linkedin.com/embed/feed/update/urn:li:share:6667420488475774976"
						frameborder="0"
						allowfullscreen=""
						title="Embedded post"
					></iframe>
				</div>
				<div className="iframe-container">
					<iframe
						src="https://www.linkedin.com/embed/feed/update/urn:li:share:6665468554126721024"
						frameborder="0"
						allowfullscreen=""
						title="Embedded post"
					></iframe>
				</div>
				<div className="iframe-container">
					<iframe
						src="https://www.linkedin.com/embed/feed/update/urn:li:share:6665126974899519488"
						frameborder="0"
						allowfullscreen=""
						title="Embedded post"
					></iframe>
				</div>
				<div className="iframe-container">
					<iframe
						src="https://www.linkedin.com/embed/feed/update/urn:li:share:6670888410154196992"
						frameborder="0"
						allowfullscreen=""
						title="Embedded post"
					></iframe>
				</div>
				<div className="iframe-container">
					<iframe
						src="https://www.linkedin.com/embed/feed/update/urn:li:share:6665091739814100992"
						frameborder="0"
						allowfullscreen=""
						title="Embedded post"
					></iframe>
				</div>
				<div className="iframe-container">
					<iframe
						src="https://www.linkedin.com/embed/feed/update/urn:li:share:6664757617656762368"
						frameborder="0"
						allowfullscreen=""
						title="Embedded post"
					></iframe>
				</div>
				<div className="iframe-container">
					<iframe
						src="https://www.linkedin.com/embed/feed/update/urn:li:share:6663776289343844352"
						frameborder="0"
						allowfullscreen=""
						title="Embedded post"
					></iframe>
				</div>
				<div className="iframe-container">
					<iframe
						src="https://www.linkedin.com/embed/feed/update/urn:li:share:6660386803121553408"
						frameborder="0"
						allowfullscreen=""
						title="Embedded post"
					></iframe>
				</div>
				<div className="iframe-container">
					<iframe
						src="https://www.linkedin.com/embed/feed/update/urn:li:share:6659034440444055552"
						frameborder="0"
						allowfullscreen=""
						title="Embedded post"
					></iframe>
				</div>
				<div className="iframe-container">
					<iframe
						src="https://www.linkedin.com/embed/feed/update/urn:li:share:6635527327709261824"
						frameborder="0"
						allowfullscreen=""
						title="Embedded post"
					></iframe>
				</div>
			</div>
		);
	}
}
